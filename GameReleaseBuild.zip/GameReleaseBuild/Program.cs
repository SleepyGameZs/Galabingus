﻿using var game = new Galabingus.Galabingus();
game.Run();
